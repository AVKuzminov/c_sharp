﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLogic
{
    public interface IRepository
    {
        Data Data { get; set; }
        User LoggedUser { get; set; }
        bool isValidLogin(string login, string pass);
        bool IsRegistrationUnique(string login, string email, string pass);
        void Registrate(string login, string email, string password);
        List<Station> UpdateFavouritesGrid();
        void DeleteStationFromFavourites(Station choosed_station);
        void DeleteStationFromFavourites(List<Station> choosed_stations);
        void AddStationToFavourites(Station choosed_station);
        void AddStationToFavourites(List<Station> choosed_stations);
        List<Station> ShowNotFavouriteStations();
        Station GetStationByName(string name);
        List<string> GetStationNamesByRoute(Route route);
        List<string> GetRouteNamesByStation(Station choosed_station);
        List<string> GetRouteNames();
        List<string> GetStationNames();
        List<Route> GetRoutesByStation(Station choseed_station);
        string MakeHash(string str);
        List<ScheduleItemWithName> GetScheduleItemsWithNameByStation(Station chosed_station);
        Route GetRouteByName(string name);
        List<ScheduleItemWithName> GetScheduleItemsWithNameByRoute(Route route);
        List<ScheduleItemWithName> GetScheduleItemsWithNameByStationAndRoute(Station chosed_station, Route route);
        List<ScheduleItem> GetScheduleItemsByStation(Station chosed_station);

    }
}
