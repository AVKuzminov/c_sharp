﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Web;


namespace DataLogic
{
    public class JSON_DataLoader : IDataLoader
    {
        const string FileName = "data.txt";
        public Data Read_data()
        {
            string s = "";
            using (var sr = new StreamReader(FileName))
            {
                s = sr.ReadLine();
            }
            Data read_data = JsonConvert.DeserializeObject<Data>(s);
            return read_data;
        }

        public void Write_data(Data downloaded_data)
        {
            string output = JsonConvert.SerializeObject(downloaded_data);
            using (var sw = new StreamWriter(FileName))
            {
                sw.WriteLine(output);
            }

        }
    }
}
