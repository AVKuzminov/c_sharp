﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLogic
{
    public class Data
    {
        public List<Station> Stations { get; set; }
        public List<User> Users { get; set; }
        public List<Route> Routes { get; set; }
    }

    public class User
    {
        public string Login { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public List<int> FavouriteStations { get; set; }
    }

    public class Station
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class ScheduleItem
    {
        public string RouteName { get; set; }
        public Station Destination { get; set; }
        public int MinutesLeft { get; set; }
    }

    public class ScheduleItemWithName
    {
        public string RouteName { get; set; }
        public string Name { get; set; }
        public int MinutesLeft { get; set; }
    }

    public class SpecialScheduleItemWithName
    {
        public string Name { get; set; }
        public int MinutesTo{ get; set; }
    }

    public class RouteStation
    {
        public Station Station { get; set; }
        public int TimeFromOrigin { get; set; }
        public int TimeFromDest { get; set; }
    }

}
