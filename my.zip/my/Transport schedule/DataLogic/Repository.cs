﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace DataLogic
{
    public class Repository:IRepository
    {
        public Data Data { get; set; }
        public User LoggedUser { get; set; }
        private IDataLoader Loader { get; set; }
        public Repository(IDataLoader loader)
        {
            Loader = loader;
            Data = new Data() {  Users = new List<User>(), Stations = new List<Station>(), Routes = new List<Route>()};
            Data = Loader.Read_data();
        }
       
        public bool isValidLogin(string login,string pass)
        {
            foreach (User user in Data.Users)
            {
                if (user.Login == login && user.Password == MakeHash(pass)) // check whether hashed pass from file equals entered hashed data
                {
                    LoggedUser = Data.Users.First(us => us.Login == login);
                    return true;
                }
            }
            return false;
        }

        public bool IsRegistrationUnique(string login,string email,string password)
        {
            foreach (User user in Data.Users)
            {
                if (user.Login == login || user.Email == email)
                    return false;
            }// if didn't find this user
            Registrate(login, email, password);
            return true;
        }

        public void Registrate(string login, string email, string password)
        {
            string hashed = MakeHash(password);
            User new_user = new DataLogic.User() { Login = login, Email = email, Password = hashed, FavouriteStations = new List<int>() };
            Data.Users.Add(new_user);
            Loader.Write_data(Data);
        }

        public List<Station> UpdateFavouritesGrid()
        {
            List<Station> result = new List<Station>();
            foreach (Station s in Data.Stations)
            {
                if (LoggedUser.FavouriteStations.Contains(s.Id))
                    result.Add(Data.Stations.First(st => st.Id == s.Id));
            }
            return result;
        }

        public void DeleteStationFromFavourites(Station choosed_station)
        {
            LoggedUser.FavouriteStations.Remove(choosed_station.Id);
            Data.Users.Find(a => a.Login == LoggedUser.Login).FavouriteStations.Remove(choosed_station.Id);
            Loader.Write_data(Data);
        }

        public void DeleteStationFromFavourites(List<Station> choosed_stations)
        {
            foreach (Station st in choosed_stations)
            {
                LoggedUser.FavouriteStations.Remove(st.Id);
                Data.Users.Find(a => a.Login == LoggedUser.Login).FavouriteStations.Remove(st.Id);
            }
            Loader.Write_data(Data);
        }

        public void AddStationToFavourites(Station choosed_station)
        {
            LoggedUser.FavouriteStations.Add(choosed_station.Id);
            Data.Users.Find(a => a.Login == LoggedUser.Login).FavouriteStations.Add(choosed_station.Id);
            Loader.Write_data(Data);
        }

        public void AddStationToFavourites(List<Station> choosed_stations)
        {
            foreach (Station st in choosed_stations)
            {
                LoggedUser.FavouriteStations.Add(st.Id);
                Data.Users.Find(a => a.Login == LoggedUser.Login).FavouriteStations.Add(st.Id);
            }
            Loader.Write_data(Data);
        }

        public List<Station> ShowNotFavouriteStations()
        {
            List<Station> result = new List<Station>();
            foreach (Station st in Data.Stations)
            {
                if (!LoggedUser.FavouriteStations.Contains(st.Id))
                    result.Add(st);
            }
            return result;
        }

        public Station GetStationByName(string name)
        {
            return Data.Stations.First(st => st.Name == name);
        }

        public List<string> GetStationNamesByRoute(Route route)
        {
            List<string> result = new List<string>();
            foreach (int st_id in route.Stations)
            {
                result.Add(Data.Stations.First(st => st.Id == st_id).Name);
            }
            return result;
        }

        public List<string> GetRouteNamesByStation(Station choosed_station)
        {
            List<string> result = new List<string>();
            List<Route> routes = GetRoutesByStation(choosed_station);
            foreach (Route route in routes)
            {
                result.Add(route.Name);
            }
            return result;
        }

        public List<string> GetRouteNames()
        {
            List<string> result = new List<string>();
            foreach (Route route in Data.Routes)
            {
                result.Add(route.Name);
            }
            return result;
        }

        public List<string> GetStationNames()
        {
            List<string> result = new List<string>();
            foreach (Station station in Data.Stations)
            {
                result.Add(station.Name);
            }
            return result;
        }

        public List<Route> GetRoutesByStation(Station choseed_station)
        {
            List<Route> result = new List<Route>();
            foreach (Route route in Data.Routes)
            {
                foreach (int id in route.Stations)
                {
                    if (id == choseed_station.Id)
                    {
                        result.Add(route);
                        break;
                    }
                }
            }
            return result;
        }

        //Code for hash was taken from http://skillcoding.com/Default.aspx?id=165
        public string MakeHash(string str)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(str);
            MD5CryptoServiceProvider CSP = new MD5CryptoServiceProvider();
            byte[] byteHash = CSP.ComputeHash(bytes);
            string hash = "";
            foreach (byte b in byteHash)
                hash += string.Format("{0:x2}", b);
            return hash;
        }

        public List<ScheduleItemWithName> GetScheduleItemsWithNameByStation(Station chosed_station)
        {
            List<ScheduleItemWithName> result = new List<ScheduleItemWithName>();
            List <ScheduleItem> temp = GetScheduleItemsByStation(chosed_station);
            foreach (ScheduleItem item in temp)
            {
                result.Add(new ScheduleItemWithName() {MinutesLeft = item.MinutesLeft, RouteName = item.RouteName, Name = item.Destination.Name });
            }
            return result;
         }

        public Route GetRouteByName(string name)
        {
            return Data.Routes.First(r => r.Name == name);
        }

        public List<ScheduleItemWithName> GetScheduleItemsWithNameByRoute(Route route)
        {
            List<ScheduleItemWithName> result = new List<ScheduleItemWithName>();
            foreach (int st_id in route.Stations)
                result.Add(new ScheduleItemWithName() { RouteName=route.Name, Name = Data.Stations.Find(st => st.Id == st_id).Name, MinutesLeft = 0 });
            int total = 0;
            for (int k = 0; k <= route.Intervals.Count - 1; k++)
            {
                total += route.Intervals[k];
                result[k + 1].MinutesLeft = total;
            }
            return result;
        }

        public List<ScheduleItemWithName> GetScheduleItemsWithNameByStationAndRoute(Station chosed_station, Route route)
        {
            List<ScheduleItemWithName> temp = GetScheduleItemsWithNameByStation(chosed_station);
            List<ScheduleItemWithName> result = temp.FindAll(siwn => siwn.RouteName == route.Name);
            return result;
        }

        public List<ScheduleItem> GetScheduleItemsByStation(Station chosed_station)
        {
            List<ScheduleItem> result = new List<ScheduleItem>();
            List<Route> routes = Data.Routes;
            DateTime currentDt = DateTime.Now;
            foreach (var route in routes)
            {
                route.RouteStations = new List<RouteStation>();
                foreach (int st_id in route.Stations)
                {
                    route.RouteStations.Add(new RouteStation() { Station = Data.Stations.First(st => st.Id == st_id) });
                }

                int totalDistance = 0;
                for (int k = 0; k <= route.Intervals.Count-1; k++)
                {
                    totalDistance += route.Intervals[k];
                    route.RouteStations[k + 1].TimeFromOrigin = totalDistance;
                }
                // Going back to fill TimeFromDest
                for (int k = route.Intervals.Count - 1; k >= 0; k--)
                    route.RouteStations[k].TimeFromDest = totalDistance - route.RouteStations[k].TimeFromOrigin;


                var Last_station = Data.Stations.First(st => st.Id == route.Stations.Last());
                var First_station = Data.Stations.First(st => st.Id == route.Stations.First());
                int? routeStationId = route.Stations.FirstOrDefault(st => st == chosed_station.Id);
                RouteStation routeStation = new RouteStation() { Station = Data.Stations.First(st => st.Id == chosed_station.Id) };
                if (routeStationId != null)
                {

                    if (routeStationId != route.Stations.Last())
                    {
                        int left = route.TimeToNextDepartureFromOrigin(route.RouteStations.FirstOrDefault(rs => rs.Station.Id == chosed_station.Id), currentDt);
                        result.Add(new ScheduleItem
                        {
                            RouteName = route.Name,
                            Destination = Data.Stations.First(st => st.Id == route.Stations.Last()),
                            MinutesLeft = left
                        });
                    }
                    if (routeStationId != route.Stations.First())
                    {
                        int left = route.TimeToNextDepartureFromDest(route.RouteStations.FirstOrDefault(rs => rs.Station.Id == chosed_station.Id), currentDt);
                        result.Add(new ScheduleItem
                        {
                            RouteName = route.Name,
                            Destination = Data.Stations.First(st => st.Id == route.Stations.First()),
                            MinutesLeft = left
                        });
                    }
                }
            }
            return result;
        }
    }
}
