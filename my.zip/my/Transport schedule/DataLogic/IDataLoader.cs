﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLogic
{
    public interface IDataLoader
    {
        Data Read_data();
        void Write_data(Data downloaded_data);
        
    }
}
