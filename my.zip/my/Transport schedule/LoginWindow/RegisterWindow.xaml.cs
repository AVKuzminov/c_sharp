﻿using DataLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Логика взаимодействия для RegisterWindow.xaml
    /// </summary>
    public partial class RegisterWindow : Window
    {
        public IRepository Repo { get; set; }
        public RegisterWindow(IRepository coming_repo)
        {
            InitializeComponent();
            Repo = coming_repo;
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool isvalid = Repo.IsRegistrationUnique(LoginText.Text, EmailText.Text, PassText.Text);
                if (isvalid)
                {
                    MessageBox.Show("Registration is successful");
                    this.Close();
                }
                else
                    MessageBox.Show("Registration error. The user already exists. Choose another login/email");
            }
            catch
            { MessageBox.Show("Something went wrong, sorry"); }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
