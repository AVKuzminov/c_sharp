﻿using DataLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Логика взаимодействия для FavouritesWindow.xaml
    /// </summary>
    public partial class FavouritesWindow : Window
    {
        IRepository Repo;
        List<Station> Choosed_stations;
        bool AddButtonActive;
        public FavouritesWindow(IRepository coming_repo)
        {
            Repo = coming_repo;
            Choosed_stations = null;
            InitializeComponent();
            DeleteButton.IsEnabled = false;
            ApplyButton.IsEnabled = false;
            AddButtonActive = false;
            UpdateFavouritesDataGrid();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            StationsWindow sw = new StationsWindow(Repo);
            sw.Show();
            this.Close();
        }

        private void ApplyButton_Click(object sender, RoutedEventArgs e)
        {
            if (Choosed_stations.Count > 2)
            {
                MessageBox.Show("You choosed more than 1 station for a query. The first one in the list would be used");
            }
            StationsWindow sw = new StationsWindow(Repo, Choosed_stations.First());
            sw.Show();
            Choosed_stations = null;
            this.Close();
        }

        private void DataGriDAction(object sender)
        {
            if (((DataGrid)sender).SelectedItem != null)
            {
                try
                {
                    Choosed_stations = new List<Station>();
                    var selected_items = ((DataGrid)sender).SelectedItems;
                    foreach (var si in selected_items)
                    {
                        Choosed_stations.Add((Station)si);
                    }
                    //Choosed_stations = (List<Station>);
                    if (AddButtonActive != true)
                    {
                        DeleteButton.IsEnabled = true;
                        ApplyButton.IsEnabled = true;
                    }
                }
                catch { }
            }
        }

        private void StationsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            DataGriDAction(sender);
        }


        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (AddButtonActive == true)
            {
                try
                {
                FavouritesLabel.Content = "Choose a station from your favourites.";
                AddButton.Content = "Add station";
                Repo.AddStationToFavourites(Choosed_stations);
                Choosed_stations = null;
                DeleteButton.IsEnabled = false;
                ApplyButton.IsEnabled = false;
                AddButton.IsEnabled = true;
                AddButtonActive = false;
                UpdateFavouritesDataGrid();
                }
                catch
                { MessageBox.Show("Choose station"); }
            }
            else
            {
                FavouritesLabel.Content = "Below is non-chosen stations list. Choose stations you want to add.";
                AddButton.Content = "Press here to confirm";
                List<Station> stations = Repo.ShowNotFavouriteStations();
                StationsGrid.ItemsSource = stations;
                AddButtonActive = true;
            }

        }

        private void UpdateFavouritesDataGrid()
        {
            StationsGrid.ItemsSource = Repo.UpdateFavouritesGrid();
            if (StationsGrid.Items.Count < 2) //если одна станация, то она будет выбрана автоматически
            {
                DeleteButton.IsEnabled = true;
                ApplyButton.IsEnabled = true;
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            Repo.DeleteStationFromFavourites(Choosed_stations);
            UpdateFavouritesDataGrid();
            Choosed_stations = null;
            DeleteButton.IsEnabled = false;
            ApplyButton.IsEnabled = false;
        }

        private void StationsGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                DataGriDAction(sender);
            }
            catch { }
        }

        private void StationsGrid_MouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                DataGriDAction(sender);
            }
            catch { }
        }
    }
}
