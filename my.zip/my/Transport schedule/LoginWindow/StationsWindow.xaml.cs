﻿using DataLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq;

namespace GUI
{
    /// <summary>
    /// Логика взаимодействия для Stations.xaml
    /// </summary>
    public partial class StationsWindow : Window
    {
        IRepository Repo;
        Station Chosed_station;
        public StationsWindow(IRepository coming_repo)
        {
            Repo = coming_repo;
            Chosed_station = null;
            InitializeComponent();
            var items = Repo.Data.Stations.Select(station => station.Name).ToList();
            StationBox.ItemsSource = items;
            Clear();
        }

        public StationsWindow(IRepository coming_repo,Station chosed_station)
        {
            Repo = coming_repo;
            Chosed_station = chosed_station;
            List<string> temp_list = new List<string>();
            temp_list.Add(Chosed_station.Name);
            InitializeComponent();
            StationBox.ItemsSource = temp_list;
            StationBox.SelectedItem = temp_list.First();
            RouteBox.ItemsSource = Repo.GetRouteNamesByStation(Chosed_station);
            DeparturesGrid.ItemsSource = Repo.GetScheduleItemsWithNameByStation(Chosed_station); //надо чтобы название станции
        }

        private void LogOutButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow(Repo);
            this.Close();
            mw.Show();
            
        }

        private void FavouritesButton_Click(object sender, RoutedEventArgs e)
        {
            FavouritesWindow fw = new FavouritesWindow(Repo);
            this.Close();
            fw.Show();
            
        }

        private void StationBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item_station = ((ComboBox)sender).SelectedItem;
            if (item_station != null)
            {
                string station_name = item_station.ToString();
                var item_route = RouteBox.SelectedItem;
                if (item_route != null)
                { //работа с известной станцией и маршрутом
                    string route_name = item_route.ToString();
                    DeparturesGrid.ItemsSource = Repo.GetScheduleItemsWithNameByStationAndRoute(Repo.GetStationByName(station_name),Repo.GetRouteByName(route_name));
                } //работа только со станцией
                else
                {
                    DeparturesGrid.ItemsSource = Repo.GetScheduleItemsWithNameByStation(Repo.GetStationByName(station_name));
                }
            }
            else
            {

            }
        }

        private void RouteBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                var item_route = ((ComboBox)sender).SelectedItem.ToString();
                if (item_route != null)
                {
                    string route_name = item_route.ToString();
                    StationBox.ItemsSource = Repo.GetStationNamesByRoute(Repo.GetRouteByName(route_name));
                    var item_station = StationBox.SelectedItem;
                    if (item_station != null)
                    {
                        //работа с известными станцией и маршрутом
                        string station_name = item_station.ToString();
                        DeparturesGrid.ItemsSource = Repo.GetScheduleItemsWithNameByStationAndRoute(Repo.GetStationByName(station_name), Repo.GetRouteByName(route_name));
                    }
                    else
                    {
                        //работа только с маршрутом
                        DeparturesGrid.ItemsSource = Repo.GetScheduleItemsWithNameByRoute(Repo.GetRouteByName(route_name));
                    }
                }
            }
            catch { }
        }
        private void Clear()
        {
            RouteBox.ItemsSource = Repo.GetRouteNames();
            RouteBox.SelectedItem = null;
            StationBox.ItemsSource = Repo.GetStationNames();
            StationBox.SelectedItem = null;
            DeparturesGrid.ItemsSource = null;
        }
        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
