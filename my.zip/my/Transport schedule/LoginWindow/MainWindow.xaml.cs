﻿using DataLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public IRepository Repo { get; set; }
        public MainWindow()
        {
            JSON_DataLoader loader = new JSON_DataLoader();
            Repo = new Repository(loader);
            InitializeComponent();
        }

        public MainWindow(IRepository coming_repo)
        {
            Repo = coming_repo;
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            RegisterWindow regwin = new RegisterWindow(Repo);
            regwin.ShowDialog();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            bool isvalid = Repo.isValidLogin(LoginText.Text,PassText.Text);
            if (isvalid)
            {
                MessageBox.Show("Authorization is successful");
                StationsWindow statwin = new StationsWindow(Repo);
                this.Close();
                statwin.Show();
            }
            else
                MessageBox.Show("Authorization error. Please, fill the fields again or register");
        }
    }
}
