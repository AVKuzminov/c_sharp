﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleChat
{
    public class ChatManager
    { 
        public event Action<string> OnLog;
        public event Action<int> OnUsersNumberChanged;

        List<User> _activeUsers = new List<User>();
       
        public void AddUser(User user)
        {
            if (_activeUsers.Contains(user))
                return;

            // YOUR CODE GOES HERE (Add connections)
            foreach (var t in _activeUsers)
            {
                
                user.OnSent += t.Receive;
                t.OnSent += user.Receive;
                
            }
            _activeUsers.Add(user);
            OnUsersNumberChanged(_activeUsers.Count);
            OnLog(String.Format("{0} JOINED", user.Username));

        }

        public void RemoveUser(User user)
        {
            if (!_activeUsers.Contains(user))
                return;

            // YOUR CODE GOES HERE (Delete connections)

            _activeUsers.Remove(user);
           OnUsersNumberChanged(_activeUsers.Count);
            OnLog(String.Format("{0} LEFT", user.Username));
            foreach (var t in _activeUsers)
            {

                user.OnSent -= t.Receive;
                t.OnSent -= user.Receive;

            }
        }
    }
}
