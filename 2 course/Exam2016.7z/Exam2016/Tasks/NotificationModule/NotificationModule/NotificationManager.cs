﻿using NotificationModule.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotificationModule
{
    class NotificationManager
    {
        EmailService email = new EmailService();
        SmsService sms = new SmsService();
        ViberService viber = new ViberService();
        WhatsAppService whatsapp = new WhatsAppService();
        
        public void ContactClient(Client client, string message)
        {
            if (client.ContactData.ContainsKey(Client.ContactEmail))
                email.ContactClient(client, message);

            if (client.ContactData.ContainsKey(Client.ContactPhone))
            {
                sms.ContactClient(client, message);
                viber.ContactClient(client, message);
                whatsapp.ContactClient(client, message);
            }
        }
    }
}
