﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalScheduler
{
	public class EventManager
	{		
		public void ProcessEvents()
		{
			
		}

		public void AddEvent(ScheduledEvent ev)
		{
			
		}

		public void RemoveEvent(ScheduledEvent ev)
		{

		}
	}
}
