﻿namespace PersonalScheduler
{
	public enum NotificationType
	{
		Email,
		Sound,
		Visual
	}

	public class ScheduledEvent
	{
		
	}
}
