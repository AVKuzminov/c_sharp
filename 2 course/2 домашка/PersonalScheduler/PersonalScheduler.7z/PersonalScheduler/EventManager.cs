﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalScheduler
{
    public delegate void RepositoryDelegate(ScheduledEvent item);

    public class EventManager
	{
        private List<ScheduledEvent> _listOfScheduledEvents = new List<ScheduledEvent>();

        public event RepositoryDelegate Add;
        public event RepositoryDelegate Remove;


		public void ProcessEvents()
		{
            List<ScheduledEvent> removinglist = new List<ScheduledEvent>();
            foreach (var i in _listOfScheduledEvents)
            {
                if (i.DateTime <= DateTime.Now)
                {
                    if (i.Notifications.Contains(NotificationType.Email))
                    {
                        
                    }
                    if (i.Notifications.Contains(NotificationType.Sound))
                    {
                        Notifiers.SoundNotifier sn = new Notifiers.SoundNotifier();
                        sn.Notify(i);
                    }
                    if (i.Notifications.Contains(NotificationType.Visual))
                    {
                        Notifiers.VisualNotifier vn = new Notifiers.VisualNotifier();
                        vn.Notify(i);
                    }
                    
                    removinglist.Add(i);
                }
            }
            foreach (var i in removinglist)
            {
                RemoveEvent(i);
            }
            removinglist.Clear();
		}

		public void AddEvent(ScheduledEvent ev)
		{
            foreach (ScheduledEvent item in _listOfScheduledEvents)
            {
                if (item.Name == ev.Name)
                    throw new ArgumentException("You cannot set two different events with the same date(time)");
            }
            _listOfScheduledEvents.Add(ev);

            _listOfScheduledEvents.Sort(delegate (ScheduledEvent a, ScheduledEvent b)
                {
                    return a.DateTime.CompareTo(b.DateTime);
                });

            Add?.Invoke(ev);
		}

		public void RemoveEvent(ScheduledEvent ev)
		{
            _listOfScheduledEvents.Remove(ev);
            Remove?.Invoke(ev);
		}
	}
}
