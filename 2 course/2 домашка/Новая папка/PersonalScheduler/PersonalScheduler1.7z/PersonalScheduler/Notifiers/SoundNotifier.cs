﻿namespace PersonalScheduler.Notifiers
{
	class SoundNotifier : INotifier
    {
		public void Notify(ScheduledEvent sv)
		{
			System.Media.SystemSounds.Exclamation.Play();
		}
	}
}
