﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Universities3.Data
{
    public class University
    {
        public int Id { get; set; }
        public string Institution { get; set; }
        public string Location { get; set; }
    }
}
