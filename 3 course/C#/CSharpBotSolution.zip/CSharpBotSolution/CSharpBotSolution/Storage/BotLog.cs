﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBotSolution.Storage
{

    //new connectionString = "server=172.26.28.15;database=Student;user id=student;password=Student1"
    //old connection string:"data source=(LocalDb)\MSSQLLocalDB;initial catalog=CSharpBotSolution.Storage.TheDatabase;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework" providerName="System.Data.SqlClient"
    public class BotLog
    {
        /// <summary>
        /// Уникальный идентификатор: время + рандомное число + mac-адрес
        /// </summary>
        public Guid ID { get; set; } //global unique identifier

         /// <summary>
        /// Регистрационное имя пользователя
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Уникальный идентификатор
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Фамилия пользователя
        /// </summary>
        public string FamilyName { get; set; }

        /// <summary>
        /// Уникальный идентификатор
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// Телефонный номер 
        /// </summary>
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Метка времени записи
        /// </summary>
        public DateTime TimeStamp { get; set; }

    }
}
