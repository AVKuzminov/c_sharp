﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBotSolution
{
    public enum BotState
    {
        /// <summary>
        /// базовое состояние бота
        /// </summary>
        None,
        /// <summary>
        /// Регистрация нового пользователя
        /// </summary>
        Registration
    }
}
