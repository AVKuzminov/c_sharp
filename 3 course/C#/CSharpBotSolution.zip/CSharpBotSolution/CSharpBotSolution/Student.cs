﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBotSolution
{
    /// <summary>
    /// Учащийся студент
    /// </summary>
    public class Student
    {
        /// <summary>
        /// Уникальный идентификатор: время + рандомное число + mac-адрес
        /// </summary>
        [Key]
        public int StudentID { get; set; } //global unique identifier

        /// <summary>
        /// Регистрационное имя пользователя
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Уникальный идентификатор
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Фамилия пользователя
        /// </summary>
        public string FamilyName { get; set; }

        /// <summary>
        /// Email
        /// </summary>
        public string Email { get; set; }

    }
}
