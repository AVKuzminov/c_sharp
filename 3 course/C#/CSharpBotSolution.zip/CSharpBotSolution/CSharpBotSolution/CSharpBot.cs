﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Types;

namespace CSharpBotSolution
//API:463370643:AAExkF5Dd2IU_hC7ZNvwPw11llgD3raJQRo
{
    /// <summary>
    /// Бизнес-логика чат-бота
    /// name: CsharpBotByArtemKuz
    /// username : TrainKuz_bot
    /// </summary>
    public class CSharpBot
    {
        private TelegramBotClient client;
        private Storage.TheDatabase db;
        // private string API = "463370643:AAExkF5Dd2IU_hC7ZNvwPw11llgD3raJQRo";

        /// <summary>
        /// Словарь состояний
        /// </summary>
        private Dictionary<int, BotState> state;

        public CSharpBot()
         {
            string token = Properties.Settings.Default.Token;
            client = new TelegramBotClient(token);
            client.OnMessage += MessageProcessor;
            db = /*new Storage.TheDatabase();*/Storage.TheDatabase.Open();
            state = new Dictionary<int, BotState>();
         }   
        public void Start()
        {
            client.StartReceiving();
        }

        public void Stop()
        {
            client.StopReceiving();
        }

        /// <summary>
        /// Обработчик сообщения
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MessageProcessor(object sender, Telegram.Bot.Args.MessageEventArgs e)
        {
            switch (e.Message.Type)
            {
                case Telegram.Bot.Types.Enums.MessageType.TextMessage:
                    TextProcessor(e.Message);
                    break;
                case Telegram.Bot.Types.Enums.MessageType.ContactMessage:
                    ContactProcessor(e.Message);
                    break;
                default:
                    client.SendTextMessageAsync(e.Message.Chat.Id,string.Format("Не понимаю о чем ты, не знаю формата {0}",e.Message.Type));
                    break;
            }
        }

        /// <summary>
        /// Обработчик текстового сообщения
        /// </summary>
        /// <param name="msg"></param>
        private void TextProcessor(Telegram.Bot.Types.Message msg)
        {
            if (msg.Text.Substring(0, 1) == "/")
            {
                CommandProcessor(msg, msg.Text.Substring(1));
            }
            else
            {
                switch (state[msg.From.Id])
                {
                    case BotState.None:
                        string message = string.Format("Привет, {0}", msg.From.FirstName);
                        client.SendTextMessageAsync(msg.Chat.Id, message);
                        break;
                    case BotState.Registration:
                        bool emailFound = false;
                        foreach (var entity in msg.Entities)
                        {
                            if (entity.Type == Telegram.Bot.Types.Enums.MessageEntityType.Email)
                            {
                                message = string.Format("Спасибо за регистрацию, {0}", msg.From.FirstName);
                                client.SendTextMessageAsync(msg.Chat.Id, message);
                                emailFound = true;
                                state[msg.From.Id] = BotState.None;
                                break;
                            }
                        }
                        if (!emailFound)
                        {
                            message = string.Format("Для завершения регистрации отправьте нам Email, {0}", msg.From.FirstName);
                            client.SendTextMessageAsync(msg.Chat.Id, message);
                        }
                        break;
                }
                
            }
        }

        /// <summary>
        /// Обработчик комманд (начинаются с "/")
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="cmd"></param>
        private void CommandProcessor(Telegram.Bot.Types.Message msg, string cmd)
        {
            switch (cmd.ToLower())
            {
                case "checkin":
                    KeyboardButton b = new KeyboardButton("Отметиться")
                    {
                        RequestContact = true,
                        RequestLocation = true //Таким образом спрашиваем локацию и телефон
                    };
                    KeyboardButton[] keys = new KeyboardButton[1] { b }; //панель конопок - нельзя не массивом
                    var markup = new Telegram.Bot.Types.ReplyMarkups.ReplyKeyboardMarkup(keys,true,true); // разметка кнопок внизу - кнопки
                    client.SendTextMessageAsync(msg.Chat.Id, "Вы отмечены, "  
                        + msg.Chat.FirstName,replyMarkup : markup); // именованный параметр (как в Питоне)
                    break;
                case "register":
                    client.SendTextMessageAsync(msg.Chat.Id, "Для регистрации отправьте Email");
                    //Переход в состояние регистрации
                    state[msg.From.Id] = BotState.Registration;
                    break;
                default:
                    client.SendTextMessageAsync(msg.Chat.Id, "неизвестная команда: " + cmd);
                    break;
            }
        }

        /// <summary>
        /// обработка присланного контакта
        /// </summary>
        private void ContactProcessor(Message msg)
        {
            //Запись в БД
            Storage.BotLog log = new Storage.BotLog()
            {
                ID = Guid.NewGuid(),
                Name = msg.Contact.FirstName,
                FamilyName = msg.Contact.LastName,
                UserID =msg.Contact.UserId,
                UserName= msg.From.Username,
                PhoneNumber = msg.Contact.PhoneNumber,
                TimeStamp = msg.Date
            };
            db.BotLogs.Add(log); 
            db.SaveChanges();
        }
    }
}
