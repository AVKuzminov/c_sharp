﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpBotSolution
{
    class Program
    {
        static void Main(string[] args)
        {
            var bot = new CSharpBot();
            bot.Start();
            Console.WriteLine("bot is ready, press a key to stop it's work");
            Console.ReadKey();
        }
    }
}
