﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork
{
    public class Container
    {
        public List<Item> Items { get; set; }
        public Money Money { get; set; }
        public List<Item> ChosenItems { get; set; }
        public List<int> InputMoney { get; set; }

        public Container(List<Item> _items, Money _money)
        {
            Items = _items;
            Money = _money;
            ChosenItems = new List<Item>();
            InputMoney = new List<int>();
            for (int i = 0; i < 8; i++)
            {
                InputMoney.Add(0);
            }
        }

    }
}
