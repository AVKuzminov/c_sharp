﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork
{
    public class Money
    {
        public int Amount_rub1 { get; set; }
        public int Amount_rub2 { get; set; }
        public int Amount_rub5 { get; set; }
        public int Amount_rub10 { get; set; }
        public int Amount_rub50 { get; set; }
        public int Amount_rub100 { get; set; }
        public int Amount_rub500 { get; set; }
        public int Amount_rub1000 { get; set; }
        public Money(int amount_rub1, int amount_rub2, int amount_rub5, int amount_rub10, int amount_rub50, int amount_rub100, int amount_rub500, int amount_rub1000)
        {
            Amount_rub1 = amount_rub1;
            Amount_rub2 = amount_rub2;
            Amount_rub5 = amount_rub5;
            Amount_rub10 = amount_rub10;
            Amount_rub50 = amount_rub50;
            Amount_rub100 = amount_rub100;
            Amount_rub500 = Amount_rub500;
            Amount_rub1000 = amount_rub1000;
        }
    }
}
