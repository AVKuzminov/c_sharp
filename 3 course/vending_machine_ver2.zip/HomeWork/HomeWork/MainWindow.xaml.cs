﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HomeWork
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public delegate void Credit(int credit);
    public partial class MainWindow : Window
    {
        int TempPlus;
        int TempMinus;
        Container data;
        List<Label> labels = new List<Label>();
        List<int> change = new List<int>();
        List<String> names = new List<String>();
        List<Button> buttons = new List<Button>();
        int totalprice;
        public event Credit CreditEvent;
        List<Item> Unavailable = new List<Item>();
        List<Item> items = new List<Item>();


        public MainWindow()
        {
            TempPlus = 0;
            TempMinus = 0;
            InitializeComponent();
            Panel panel = new Panel();
            panel.Show();
            panel.AddMoneyEvent += AddMoney;
            panel.ChangeFunc += give_change;
            this.Left = System.Windows.SystemParameters.PrimaryScreenWidth / 2 - 620;
            this.Top = System.Windows.SystemParameters.PrimaryScreenHeight / 2 - 380;
            data = SerializationClass.Read();
            Money money = data.Money;
            items = data.Items;
            buttons.Add(product1);
            buttons.Add(product2);
            buttons.Add(product3);
            buttons.Add(product4);
            buttons.Add(product5);
            buttons.Add(product6);
            buttons.Add(product7);
            buttons.Add(product8);
            buttons.Add(product9);
            buttons.Add(product10);
            buttons.Add(product11);
            buttons.Add(product12);
            labels.Add(product_name1);
            labels.Add(product_name2);
            labels.Add(product_name3);
            labels.Add(product_name4);
            labels.Add(product_name5);
            labels.Add(product_name6);
            labels.Add(product_name7);
            labels.Add(product_name8);
            labels.Add(product_name9);
            labels.Add(product_name10);
            labels.Add(product_name11);
            labels.Add(product_name12);
            this.product1.Click += Button_Click;
            this.product2.Click += Button_Click;
            this.product3.Click += Button_Click;
            this.product4.Click += Button_Click;
            this.product5.Click += Button_Click;
            this.product6.Click += Button_Click;
            this.product7.Click += Button_Click;
            this.product8.Click += Button_Click;
            this.product9.Click += Button_Click;
            this.product10.Click += Button_Click;
            this.product11.Click += Button_Click;
            this.product12.Click += Button_Click;
            for (int i = 0; i < items.Count; i++)
            {
                Name = String.Format("product_name{0}", i);
                buttons[i].Content = items[i].Price + " RUB";
                labels[i].Content = items[i].Name;
                if (!QuantitiveCheck(items[i]))
                {
                    buttons[i].IsEnabled = false;
                    buttons[i].Content = "[SOLD] " + buttons[i].Content.ToString();
                }
            }
            AvailableCheck();
        }

        public bool QuantitiveCheck(Item item)
        {
            return (item.Amount > 0);
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (sender is Button)
            {
                var button = sender as Button;
                string tag = button.Name as string;
                string name = "product_name" + tag.Substring(7);
                for (int i = 0; i < data.Items.Count; i++)
                {
                    if (labels[i].Name.ToString() == name)
                    {
                        TempMinus += data.Items[i].Price;
                        if (TempPlus >= data.Items[i].Price && (TempPlus - TempMinus) > 0)
                        {
                            if (change_check(TempPlus - TempMinus, data))
                            {
                                MessageBox.Show("It would be impossible to give change. Please, insert more money/push 'CHANGE' button");
                            }
                            else
                            {
                                CreditChange(TempPlus - TempMinus);
                                data.Items[i].Amount--;
                                data.ChosenItems.Add(data.Items[i]);
                            }
                        }
                        else
                        {
                            MessageBox.Show("You don't have enough money");
                        }
                    }
                }
                AvailableCheck();
            }
        }

        public bool AvailableCheck()
        {
            bool a = true;
            foreach (var item in items)
            {
                a = change_check(TempPlus - TempMinus - item.Price, data);
                if (!a && QuantitiveCheck(item) && (TempPlus - TempMinus > 0) )
                {
                    foreach (var item1 in Unavailable.ToArray())
                    {
                        if (item.Name == item1.Name)
                        {
                            Unavailable.Remove(item1);
                        }
                    }
                    int i = 0;
                    for (i = 0; i < items.Count; i++)
                    {
                        if (items[i].Name == item.Name)
                            break;
                    }
                    buttons[i].IsEnabled = true;
                }
                else
                {
                    int i = 0;
                    for (i = 0; i < items.Count; i++)
                    {
                        if (items[i].Name == item.Name)
                            break;
                    }
                    buttons[i].IsEnabled = false;
                    Unavailable.Add(item);
                }
            }
            return (a);
        }

        public bool change_check(int temp, Container dataTemp)
        {
            int a1 = dataTemp.Money.Amount_rub10;
            int a2 = dataTemp.Money.Amount_rub5;
            int a3 = dataTemp.Money.Amount_rub2;
            int a4 = dataTemp.Money.Amount_rub1;
            totalprice = temp;
            change.Clear();
            change.Add(0);
            change.Add(0);
            change.Add(0);
            change.Add(0);
            while (totalprice >= 10 && a1 > 0)
            {
                change[0]++;
                totalprice -= 10;
                a1--;
            }
            while (totalprice >= 5 && a2 > 0)
            {
                change[1]++;
                totalprice -= 5;
                a2--;
            }
            while (totalprice >= 2 && a3 > 0)
            {
                change[2]++;
                totalprice -= 2;
                a3--;
            }
            while (totalprice >= 1 && a4 > 0)
            {
                change[3]++;
                totalprice -= 1;
                a4--;
            }
            return (totalprice != 0);
        }


        public void CreditChange(int money)
        {
            this.CreditLabel.Content = string.Format("Credit = {0}RUB", money);
        }

        private List<int> give_change()
        {
            if (!change_check(TempPlus - TempMinus, data) && (TempPlus - TempMinus) > 0)
            {
                while (totalprice >= 10 && data.Money.Amount_rub10 > 0)
                {
                    change[0]++;
                    totalprice -= 10;
                    data.Money.Amount_rub10--;
                }
                while (totalprice >= 5 && data.Money.Amount_rub5 > 0)
                {
                    change[1]++;
                    totalprice -= 5;
                    data.Money.Amount_rub5--;
                }
                while (totalprice >= 2 && data.Money.Amount_rub2 > 0)
                {
                    change[2]++;
                    totalprice -= 2;
                    data.Money.Amount_rub2--;
                }
                while (totalprice >= 1 && data.Money.Amount_rub1 > 0)
                {
                    change[3]++;
                    totalprice -= 1;
                    data.Money.Amount_rub1--;
                }
                change.Add(totalprice);
                CreditChange(0);
            }
            else
            {
                change.Add(1);
                change.Add(1);
                change.Add(1);
                change.Add(1);
            }
            return (change);
        }

        public void AddMoney(int money)
        {
            switch (money)
            {
                case 0:
                    TempPlus += 1;
                    data.Money.Amount_rub1++;
                    break;
                case 1:
                    TempPlus += 2;
                    data.Money.Amount_rub2++;
                    break;
                case 2:
                    TempPlus += 5;
                    data.Money.Amount_rub5++;
                    break;
                case 3:
                    TempPlus += 10;
                    data.Money.Amount_rub10++;
                    break;
                case 4:
                    TempPlus += 50;
                    data.Money.Amount_rub50++;
                    break;
                case 5:
                    TempPlus += 100;
                    data.Money.Amount_rub100++;
                    break;
                case 6:
                    TempPlus += 500;
                    data.Money.Amount_rub500++;
                    break;
                case 7:
                    TempPlus += 1000;
                    data.Money.Amount_rub1000++;
                    break;
            }
            data.InputMoney[money]++;
            CreditChange(TempPlus-TempMinus);
            AvailableCheck();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SerializationClass.Write(data);
        }
    }
}
