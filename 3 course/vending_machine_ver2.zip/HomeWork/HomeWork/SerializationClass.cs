﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork
{
    static class SerializationClass
    {
        public static void Write(Container container)
        {
            string relative_path = "../../text.txt"; //@"c:\text.txt";
            using (StreamWriter sw = new StreamWriter(relative_path)) 
            {
                for (int i = 0; i < container.Items.Count; i++)
                {
                    sw.WriteLine(container.Items[i].Name);
                    sw.WriteLine(container.Items[i].Price);
                    sw.WriteLine(container.Items[i].Amount);
                }
                sw.WriteLine(container.Money.Amount_rub1);
                sw.WriteLine(container.Money.Amount_rub2);
                sw.WriteLine(container.Money.Amount_rub5);
                sw.WriteLine(container.Money.Amount_rub10);
                sw.WriteLine(container.Money.Amount_rub50);
                sw.WriteLine(container.Money.Amount_rub100);
                sw.WriteLine(container.Money.Amount_rub500);
                sw.WriteLine(container.Money.Amount_rub1000);
            }
        }

        public static Container Read()
        {
            string relative_path = "../../text.txt";
            List<Item> items = new List<Item>();
            Money money = new Money(0, 0, 0, 0, 0, 0, 0, 0);
            Container container = new Container(items,money);
            try
            {
                using (StreamReader sr = new StreamReader(relative_path))
                {
                    string line = "";
                    line = sr.ReadLine();
                    for (int i = 0; i < 12; i++)
                    {
                        Item item = new Item();
                        item.Name = line;
                        line = sr.ReadLine();
                        item.Price = int.Parse(line);
                        line = sr.ReadLine();
                        item.Amount = int.Parse(line);
                        line = sr.ReadLine();
                        container.Items.Add(item);
                    }
                    container.Money.Amount_rub1 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub2 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub5 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub10 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub50 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub100 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub500 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub1000 = int.Parse(line);
                    line = sr.ReadLine();
                }
            }
            catch
            {
                SerializationClass.Create();
                using (StreamReader sr = new StreamReader(relative_path))
                {
                    string line = "";
                    line = sr.ReadLine();
                    for (int i = 0; i < 12; i++)
                    {
                        Item item = new Item();
                        item.Name = line;
                        line = sr.ReadLine();
                        item.Price = int.Parse(line);
                        line = sr.ReadLine();
                        item.Amount = int.Parse(line);
                        line = sr.ReadLine();
                        container.Items.Add(item);
                    }
                    container.Money.Amount_rub1 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub2 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub5 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub10 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub50 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub100 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub500 = int.Parse(line);
                    line = sr.ReadLine();
                    container.Money.Amount_rub1000 = int.Parse(line);
                    line = sr.ReadLine();
                }
                }
            return container;
        }

        public static void Create()
        {
            List<Item> items = new List<Item>();
            items.Add(new Item("Виноградный Кобэ Кёрюти",113,0));
            items.Add(new Item("Апельсиновый Кобэ Кёрюти", 113, 6));
            items.Add(new Item("Лимонад Краен Сенчан", 214, 6));
            items.Add(new Item("SANGARIA", 110, 6));
            items.Add(new Item("SANGARIA bottle", 186, 6));
            items.Add(new Item("Дайдо Энерджи Джим", 156, 6));
            items.Add(new Item("Dr. Pepper", 70, 6));
            items.Add(new Item("Лимонад Вкус Японии", 190, 6));
            items.Add(new Item("Крем-содовая (белая)", 115, 6));
            items.Add(new Item("Крем-содовая (виноград)", 115, 6));
            items.Add(new Item("Miracle Body", 188, 6));
            items.Add(new Item("Дайдо Мистио Кристалл", 156, 6));
            Money money = new Money(100,100,50,100,0,0,0,0);
            Container first = new Container(items,money);
            Write(first);
        }
    }
}
