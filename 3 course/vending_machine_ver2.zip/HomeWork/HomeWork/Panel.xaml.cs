﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HomeWork
{
    /// <summary>
    /// Interaction logic for Panel.xaml
    /// </summary>

    public delegate void AddMoney(int price);
    //public delegate int Change(string a, out List<int> b);
    public partial class Panel : Window
    {
        public event AddMoney AddMoneyEvent;
        public Func<List<int>> ChangeFunc;
        public Panel()
        {
            InitializeComponent();
            this.Left = System.Windows.SystemParameters.PrimaryScreenWidth / 2 + 240;
            this.Top = System.Windows.SystemParameters.PrimaryScreenHeight / 2 - 380;
            this.insert_1.Click += Button_Click;
            this.insert_2.Click += Button_Click;
            this.insert_5.Click += Button_Click;
            this.insert_10.Click += Button_Click;
            this.insert_50.Click += Button_Click;
            this.insert_100.Click += Button_Click;
            this.insert_500.Click += Button_Click;
            this.insert_1000.Click += Button_Click;
        }

       

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button)
            {
                var button = sender as Button;
                var tag = int.Parse(button.Tag as string);
                AddMoneyEvent?.Invoke(tag-1);
            }
        }

        private void change_Click(object sender, RoutedEventArgs e)
        {
            List<int> list = ChangeFunc?.Invoke();
            int sum = list[0] * 10 + list[1] * 5 + list[2] * 2 + list[3] * 1;
            if (list[4] > 0)
            {
                MessageBox.Show("It is impossibe to give change, we are out of coins. Buy something more, please");
            }
            else
                MessageBox.Show(string.Format("You get {0}*1 + {1}*2 + {2}*5 + {3}*10 = {4} RUB", list[3], list[2], list[1],list[0], sum));
        }

        private List<int> give_change(int totalprice)
        {
            List<int> change = new List<int>();
            List<int> range = new List<int>();
            range.Add(1);
            range.Add(2);
            range.Add(5);
            range.Add(10);
            range.Add(50);
            range.Add(100);
            range.Add(500);
            range.Add(1000);
            for (int i = 0; i < 8; i++)
            {
                change.Add(0);
                while (totalprice >= range[7 - i])
                {
                    change[7 - i]++;
                    totalprice -= range[7 - i];
                }
            }
            return (change);
        }
    }
}
