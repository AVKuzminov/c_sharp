﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace vending_machine
{
    /// <summary>
    /// Логика взаимодействия для panel.xaml
    /// </summary>
    public delegate void PanelClick(int type);
    public partial class panel : Window
    {
        public event PanelClick PanelClickEvent;
        public panel()
        {
            InitializeComponent();
            this.Left = System.Windows.SystemParameters.PrimaryScreenWidth / 2 + 100;
            this.Top = System.Windows.SystemParameters.PrimaryScreenHeight / 2 - 400;
            insert1RubButton.Click += Button_Click;
            insert2RubButton.Click += Button_Click;
            insert5RubButton.Click += Button_Click;
            insert10RubButton.Click += Button_Click;
            insert50RubButton.Click += Button_Click;
            insert100RubButton.Click += Button_Click;
            insert500RubButton.Click += Button_Click;
            insert1000RubButton.Click += Button_Click;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int buttonnumber = 0;
            if (sender is Button)
            {
                Button button = sender as Button;
                buttonnumber = int.Parse(button.Tag.ToString());
            }
            PanelClickEvent?.Invoke(buttonnumber);
        }
    }
}
