﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace vending_machine
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Container container = new Container();
        double Balance = 0;
        List<Label> labels = new List<Label>();
        List<Button> buttons = new List<Button>();
        public MainWindow()
        {
            InitializeComponent();
            this.Left = SystemParameters.PrimaryScreenWidth / 2 - 600;
            this.Top = SystemParameters.PrimaryScreenHeight / 2 - 400;
            container = Read();

            product1label.Content = container.Items[0].Name;
            labels.Add(product1label);
            product1button.Content = container.Items[0].Price.ToString() + " RUB";
            product1button.Click += Button_Click;
            buttons.Add(product1button);

            product2label.Content = container.Items[1].Name;
            labels.Add(product2label);
            product2button.Content = container.Items[1].Price.ToString() + " RUB";
            product2button.Click += Button_Click;
            buttons.Add(product2button);

            product3label.Content = container.Items[2].Name;
            labels.Add(product3label);
            product3button.Content = container.Items[2].Price.ToString() + " RUB";
            product3button.Click += Button_Click;
            buttons.Add(product3button);

            product4label.Content = container.Items[3].Name;
            labels.Add(product4label);
            product4button.Content = container.Items[3].Price.ToString() + " RUB";
            product4button.Click += Button_Click;
            buttons.Add(product4button);

            product5label.Content = container.Items[4].Name;
            labels.Add(product5label);
            product5button.Content = container.Items[4].Price.ToString() + " RUB";
            product5button.Click += Button_Click;
            buttons.Add(product5button);

            product6label.Content = container.Items[5].Name;
            labels.Add(product6label);
            product6button.Content = container.Items[5].Price.ToString() + " RUB";
            product6button.Click += Button_Click;
            buttons.Add(product6button);

            panel panel1 = new panel();
            panel1.Show();
            panel1.PanelClickEvent += MoneyAdded;
            Available();
        }

        private void Window_Unloaded(object sender, RoutedEventArgs e)
        {
            Write(container.Items,container.Money);
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button)
            {
                var button = sender as Button;
                var buttontag = int.Parse(button.Tag.ToString());
                buttontag--;
                for (int i = 0; i < container.Items.Count; i++)
                {
                    if (labels[buttontag].Content.ToString() == container.Items[i].Name)
                    {
                        if (IsChangePossible(container.Items[i].Price))
                        {
                            if (container.Items[i].Amount > 0)
                            {
                                Balance -= container.Items[i].Price;
                                container.Items[i].Amount--;
                                amountlabel.Content = "You have " + Balance.ToString() + " RUB";
                                Available();
                            }
                            else
                            {
                                MessageBox.Show("Sorry, we are out of this product");
                            }
                        }
                        else
                        {
                            MessageBox.Show("You can't take this product, because giving change would be impossible");
                        }
                    }
                }
            }
        }

        public void Available()
        {
            for (int i = 0; i < buttons.Count; i++)
            {
                int tag = int.Parse(buttons[i].Tag.ToString());

                if (container.Items[tag - 1].Amount <= 0)
                {
                    buttons[i].Content = "Sorry, 0 left";
                    buttons[i].IsEnabled = false;
                }
                else
                {
                    if (IsChangePossible(container.Items[tag - 1].Price))
                    {
                        buttons[i].IsEnabled = true;
                    }
                    else
                    {
                        buttons[i].IsEnabled = false;
                    }
                }
            }
        }
        

        public void MoneyAdded(int type)
        {
            switch (type)
            {
                case 1:
                    container.Money.Amount1++;
                    Balance += 1;
                    break;
                case 2:
                    container.Money.Amount2++;
                    Balance += 2;
                    break;
                case 5:
                    container.Money.Amount5++;
                    Balance += 5;
                    break;
                case 10:
                    container.Money.Amount10++;
                    Balance += 10;
                    break;
                case 50:
                    container.Money.Amount50++;
                    Balance += 50;
                    break;
                case 100:
                    container.Money.Amount100++;
                    Balance += 100;
                    break;
                case 500:
                    container.Money.Amount500++;
                    Balance += 500;
                    break;
                case 1000:
                    container.Money.Amount1000++;
                    Balance += 1000;
                    break;
            }
            Available();
            amountlabel.Content = "You have " + Balance.ToString() + " RUB";
        }


        public bool IsChangePossible(double newItem_Price)
        {
            int amount1 = container.Money.Amount1;
            int amount2 = container.Money.Amount2;
            int amount5 = container.Money.Amount5;
            int amount10 = container.Money.Amount10;
            double change = Balance - newItem_Price;
            while (change >= 10 && amount10 > 0)
            {
                change -= 10;
                amount10--;
            }
            while (change >= 5 && amount5 > 0)
            {
                change -= 5;
                amount5--;
            }
            while (change >= 2 && amount2 > 0)
            {
                change -= 2;
                amount2--;
            }
            while (change >= 1 && amount1 > 0)
            {
                change -= 1;
                amount1--;
            }
            return (change == 0);
        }


        private void changebutton_Click(object sender, RoutedEventArgs e)
        {
            if (IsChangePossible(0))
            {
                MessageBox.Show("You've got " + Balance.ToString() + " RUB");
                Balance = 0;
                amountlabel.Content = "You have " + Balance.ToString() + " RUB";
            }
            else
            {
                MessageBox.Show("Sorry, you can't get the change. Please insert money or buy something");
            }
            Available();

        }

        public Container Read()
        {
            List<SingleItem> returnlist = new List<SingleItem>();
            MoneyAmout resultmomey = new MoneyAmout();
            string path = "../../data.txt";
            try
            {
                if (File.Exists(path))
                {
                    using (StreamReader sr = new StreamReader(path))
                    {
                        string oneline;
                        string[] onelinelist;
                        char[] sep = new char[1];
                        sep[0] = ',';
                        for (int i = 0; i < 6; i++)
                        {
                            oneline = "";
                            oneline = sr.ReadLine();
                            onelinelist = oneline.Split(sep);
                            SingleItem item = new SingleItem(onelinelist[0], double.Parse(onelinelist[1]), int.Parse(onelinelist[2]));
                            returnlist.Add(item);
                        }
                        oneline = sr.ReadLine();
                        onelinelist = oneline.Split(sep);
                        resultmomey = new MoneyAmout(int.Parse(onelinelist[0]), int.Parse(onelinelist[1]), int.Parse(onelinelist[2]), int.Parse(onelinelist[3]), int.Parse(onelinelist[4]), int.Parse(onelinelist[5]), int.Parse(onelinelist[6]), int.Parse(onelinelist[7]));
                        container.Items = returnlist;
                        container.Money = resultmomey;
                    }
                }

                else
                {
                    List<SingleItem> templist = new List<SingleItem>();
                    SingleItem newitem1 = new SingleItem("For +2 eyes", 30, 7);
                    templist.Add(newitem1);
                    SingleItem newitem2 = new SingleItem("For +3 eyes", 41, 6);
                    templist.Add(newitem2);
                    SingleItem newitem3 = new SingleItem("For +4 eyes", 44, 5);
                    templist.Add(newitem3);
                    SingleItem newitem4 = new SingleItem("For -2 eyes", 3, 0);
                    templist.Add(newitem4);
                    SingleItem newitem5 = new SingleItem("For -3 eyes", 55, 6);
                    templist.Add(newitem5);
                    SingleItem newitem6 = new SingleItem("For -4 eyes", 500, 7);
                    templist.Add(newitem6);
                    MoneyAmout tempMa = new MoneyAmout(100, 100, 100, 100, 10, 10, 10, 10);
                    Write(templist,tempMa);
                    container = Read();
                }
            }

            catch
            {
                MessageBox.Show("An error occured while reading the file. Please, check it and restart the apoplication");
            }

            return container;
        }

        public void Write(List<SingleItem> list, MoneyAmout ma)
        {
            string path = "../../data.txt";
            using (StreamWriter sw = new StreamWriter(path))
            {
                string line = "";
                foreach (var item in list)
                {
                    line = "";
                    line = item.Name + "," + item.Price.ToString() + "," + item.Amount.ToString();
                    sw.WriteLine(line);
                }
                line = "";
                line = ma.Amount1.ToString() + ',' + ma.Amount2.ToString() + ',' + ma.Amount5.ToString() + ',' + ma.Amount10.ToString() + ',' + ma.Amount50.ToString() + ',' + ma.Amount100.ToString() + ',' + ma.Amount500.ToString() + ',' + ma.Amount1000.ToString();
                sw.WriteLine(line);
            }
        }


    }
}
