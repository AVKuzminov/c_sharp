﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vending_machine
{
    public class MoneyAmout
    {
        public int Amount1 { get; set; }
        public int Amount2 { get; set; }
        public int Amount5 { get; set; }
        public int Amount10 { get; set; }
        public int Amount50 { get; set; }
        public int Amount100 { get; set; }
        public int Amount500 { get; set; }
        public int Amount1000 { get; set; }
        public MoneyAmout(int amount1, int amount2, int amount5, int amount10, int amount50, int amount100, int amount500, int amount1000)
        {
            Amount1 = amount1;
            Amount2 = amount2;
            Amount5 = amount5;
            Amount10 = amount10;
            Amount100 = amount100;
            Amount500 = amount500;
            Amount1000 = amount1000;
        }
        public MoneyAmout()
        {

        }
    }
}
