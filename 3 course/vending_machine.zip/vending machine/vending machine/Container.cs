﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vending_machine
{
    public class Container
    {
        public List<SingleItem> Items { get; set; }
        public MoneyAmout Money { get; set; }
        public Container(List<SingleItem> items, MoneyAmout money)
        {
            Items = items;
            Money = money;
        }
        public Container()
        {

        }
    }
}
